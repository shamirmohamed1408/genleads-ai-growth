import { Bot } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="py-12 border-t border-border/50 bg-background/50 backdrop-blur-sm">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <Bot className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-bold text-lg">GenLeads</div>
              <div className="text-sm text-muted-foreground">AI-Powered Growth for Your Business</div>
            </div>
          </div>
          
          <div className="text-center md:text-right space-y-2">
            <div className="flex flex-col md:flex-row gap-4 md:gap-6 justify-center md:justify-end mb-2">
              <Link to="/privacy-policy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms-conditions" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                Terms & Conditions
              </Link>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 GenLeads. All rights reserved.
            </p>
            <p className="text-xs text-muted-foreground">
              Built with AI innovation in mind
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;