import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, ArrowRight, Star, TrendingUp, Award, CheckCircle } from "lucide-react";

const Portfolio = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const portfolioItems = [
    {
      title: "MediCare Clinic",
      industry: "Healthcare",
      results: "60% reduction in no-shows",
      description: "AI calling assistant implementation for appointment management",
      metrics: ["300+ appointments managed", "90% patient satisfaction", "20 hours saved weekly"]
    },
    {
      title: "TechStart Solutions",
      industry: "Technology",
      results: "300% lead increase",
      description: "Complete digital transformation with AI-powered workflows",
      metrics: ["500+ qualified leads", "150% ROI improvement", "5x faster response time"]
    },
    {
      title: "Local Restaurant Chain",
      industry: "Food & Beverage",
      results: "150% sales increase",
      description: "Social media automation and customer engagement strategy",
      metrics: ["2M+ social reach", "80% engagement boost", "200+ new customers monthly"]
    }
  ];

  return (
    <section id="portfolio" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our <span className="text-primary">Success Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real results from businesses that transformed with our AI solutions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {portfolioItems.map((item, index) => (
            <Card 
              key={index}
              className="group hover:border-primary/30 transition-all duration-500 animate-scale-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="w-5 h-5 text-primary" />
                  <span className="text-sm text-primary font-medium">{item.industry}</span>
                </div>
                <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                  {item.title}
                </CardTitle>
                <div className="text-2xl font-bold text-primary mb-2">
                  {item.results}
                </div>
                <CardDescription className="text-base leading-relaxed">
                  {item.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0">
                <ul className="space-y-2 mb-6">
                  {item.metrics.map((metric, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="w-4 h-4 text-primary" />
                      {metric}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button 
            variant="hero" 
            size="lg"
            onClick={scrollToContact}
            className="group"
          >
            <Users className="w-5 h-5" />
            Start Your Success Story
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;