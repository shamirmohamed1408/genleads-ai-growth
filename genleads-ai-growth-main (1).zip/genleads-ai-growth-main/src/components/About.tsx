import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, Share2, Target } from "lucide-react";

const About = () => {
  const services = [
    {
      icon: Mail,
      title: "AI Campaign Automation",
      description: "Intelligent email sequences that adapt to customer behavior"
    },
    {
      icon: Phone,
      title: "AI Calling Assistants",
      description: "Smart virtual agents for clinics and healthcare providers"
    },
    {
      icon: Share2,
      title: "Social Media Management",
      description: "AI-powered content creation and engagement strategies"
    },
    {
      icon: Target,
      title: "Meta Ads Optimization",
      description: "Data-driven campaigns that maximize your advertising ROI"
    }
  ];

  return (
    <section className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Transforming Businesses with{" "}
            <span className="text-primary">AI Innovation</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            We help businesses leverage AI to simplify workflows, boost conversions, and maximize ROI. 
            Our solutions include email automation, AI calling assistants, social media management, and ad campaigns.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index} 
                className="group hover:border-primary/30 cursor-pointer transform hover:scale-105 transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gradient-primary rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:shadow-glow transition-all duration-300">
                    <Icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-3 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default About;