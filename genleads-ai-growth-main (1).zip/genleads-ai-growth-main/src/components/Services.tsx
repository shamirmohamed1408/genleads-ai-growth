import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Phone, Share2, Target, ArrowRight, Play, BarChart3, Users, TrendingUp } from "lucide-react";

const Services = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const services = [
    {
      icon: Mail,
      title: "AI Email Campaign",
      description: "Automate personalized email campaigns that boost engagement and conversions.",
      features: ["Smart segmentation", "A/B testing", "Performance analytics", "24/7 automation"],
      cta: "Book a Consultation"
    },
    {
      icon: Phone,
      title: "AI Calling Assistant",
      subtitle: "Virtual Agent",
      description: "AI-powered calling agents that handle appointments, reminders, and client/patient queries.",
      features: ["Appointment scheduling", "Patient follow-ups", "Insurance verification", "Multi-language support"],
      cta: "View Demo",
      hasDemo: true,
      hasConsultation: true
    },
    {
      icon: Share2,
      title: "Social Media Management",
      description: "Consistent posting, branding, and engagement strategies tailored to your audience.",
      features: ["Content creation", "Automated posting", "Engagement tracking", "Brand consistency"],
      cta: "Book a Consultation"
    },
    {
      icon: Target,
      title: "Meta Ads & Paid Campaigns",
      description: "ROI-driven ad campaigns on Facebook, Instagram, and Google to grow sales.",
      features: ["Campaign optimization", "Audience targeting", "Budget management", "Performance reporting"],
      cta: "Book a Consultation"
    },
  ];

  return (
    <section id="services" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Our <span className="text-primary">AI Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive AI solutions designed to accelerate your business growth
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index} 
                className="group hover:border-primary/30 transition-all duration-500 animate-scale-in"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center shrink-0 group-hover:shadow-glow transition-all duration-300">
                      <Icon className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                        {service.title}
                      </CardTitle>
                      {service.subtitle && (
                        <div className="text-sm text-primary font-medium mb-2">
                          {service.subtitle}
                        </div>
                      )}
                      <CardDescription className="text-base leading-relaxed">
                        {service.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="flex gap-3">
                    {service.hasDemo && (
                      <Button variant="outline-primary" size="sm" className="group">
                        <Play className="w-4 h-4" />
                        View Demo
                      </Button>
                    )}
                    <Button 
                      variant="default" 
                      size="sm" 
                      onClick={scrollToContact}
                      className="group flex-1 sm:flex-none"
                    >
                      {service.hasConsultation ? "Consultation" : service.cta}
                      <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;