import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, ArrowRight, TrendingUp, Target, DollarSign, Users } from "lucide-react";

const MetaAdsResults = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const results = [
    {
      metric: "ROAS",
      value: "4.2x",
      description: "Average Return on Ad Spend",
      icon: DollarSign,
      trend: "+180%"
    },
    {
      metric: "Cost Per Lead",
      value: "$12",
      description: "Average across all campaigns",
      icon: Target,
      trend: "-65%"
    },
    {
      metric: "Monthly Leads",
      value: "2,500+",
      description: "Qualified leads generated",
      icon: Users,
      trend: "+320%"
    }
  ];

  const caseStudies = [
    {
      client: "Real Estate Agency",
      spend: "$5,000/month",
      leads: "150+ qualified leads",
      conversion: "12% conversion rate",
      roi: "380% ROI"
    },
    {
      client: "Fitness Center",
      spend: "$3,000/month",
      leads: "200+ membership inquiries",
      conversion: "18% conversion rate",
      roi: "450% ROI"
    },
    {
      client: "Beauty Salon",
      spend: "$2,500/month",
      leads: "100+ booking requests",
      conversion: "25% conversion rate",
      roi: "520% ROI"
    }
  ];

  return (
    <section id="meta-ads-results" className="py-24 relative bg-muted/20">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="text-primary">Meta Ads</span> Performance Results
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Data-driven insights and proven results from our advertising campaigns
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {results.map((result, index) => {
            const Icon = result.icon;
            return (
              <Card 
                key={index}
                className="text-center group hover:border-primary/30 transition-all duration-500 animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="pt-6">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{result.value}</div>
                  <div className="font-semibold mb-1">{result.metric}</div>
                  <p className="text-sm text-muted-foreground mb-2">{result.description}</p>
                  <div className="flex items-center justify-center gap-1 text-sm text-green-500">
                    <TrendingUp className="w-4 h-4" />
                    {result.trend}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Case Studies */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-center mb-8">Campaign Case Studies</h3>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {caseStudies.map((study, index) => (
              <Card 
                key={index}
                className="group hover:border-primary/30 transition-all duration-500 animate-scale-in"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg group-hover:text-primary transition-colors">
                    {study.client}
                  </CardTitle>
                  <CardDescription>
                    Monthly Ad Spend: <span className="text-primary font-semibold">{study.spend}</span>
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Leads Generated:</span>
                      <span className="text-sm font-semibold">{study.leads}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Conversion Rate:</span>
                      <span className="text-sm font-semibold">{study.conversion}</span>
                    </div>
                    <div className="flex justify-between border-t border-border/50 pt-2">
                      <span className="text-sm text-muted-foreground">Total ROI:</span>
                      <span className="text-sm font-bold text-primary">{study.roi}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Button 
            variant="hero" 
            size="lg"
            onClick={scrollToContact}
            className="group"
          >
            <BarChart3 className="w-5 h-5" />
            Get Similar Results
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default MetaAdsResults;