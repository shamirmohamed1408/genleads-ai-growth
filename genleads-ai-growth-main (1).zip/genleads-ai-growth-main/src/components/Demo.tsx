import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Play, Calendar, ExternalLink } from "lucide-react";

const Demo = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="demo" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Experience Our <span className="text-primary">AI Solutions</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See our AI assistants in action and book your personalized consultation
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* VAPI Demo */}
          <Card className="group hover:border-primary/30 transition-all duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 group-hover:shadow-glow transition-all duration-300">
                <Play className="w-8 h-8 text-primary-foreground" />
              </div>
              <CardTitle className="text-2xl mb-2">Live AI Demo</CardTitle>
              <CardDescription className="text-base">
                Experience our AI calling assistant in real-time with VAPI integration
              </CardDescription>
            </CardHeader>
            
            <CardContent className="text-center space-y-4">
              <Button 
                variant="hero" 
                size="lg" 
                className="w-full group"
                onClick={() => window.open('https://vapi.ai/demo', '_blank')}
              >
                <ExternalLink className="w-5 h-5" />
                Try VAPI Demo
              </Button>
              
              <p className="text-sm text-muted-foreground">
                Interactive voice AI demonstration
              </p>
            </CardContent>
          </Card>

          {/* Consultation Booking */}
          <Card className="group hover:border-primary/30 transition-all duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 group-hover:shadow-glow transition-all duration-300">
                <Calendar className="w-8 h-8 text-primary-foreground" />
              </div>
              <CardTitle className="text-2xl mb-2">Free Consultation</CardTitle>
              <CardDescription className="text-base">
                Discuss your business needs and explore tailored AI solutions
              </CardDescription>
            </CardHeader>
            
            <CardContent className="text-center space-y-4">
              <Button 
                variant="outline-primary" 
                size="lg" 
                className="w-full group"
                onClick={scrollToContact}
              >
                <Calendar className="w-5 h-5" />
                Book Consultation
              </Button>
              
              <p className="text-sm text-muted-foreground">
                30-minute strategy session
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Demo;