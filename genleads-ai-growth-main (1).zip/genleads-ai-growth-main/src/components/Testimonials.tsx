import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import { useEffect, useState } from "react";

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: "Dr. Sarah Johnson",
      company: "MediCare Clinic",
      rating: 5,
      text: "GenLeads' AI calling assistant reduced our appointment no-shows by 60%. The automation is seamless!"
    },
    {
      name: "Michael Chen",
      company: "TechStart Solutions",
      rating: 5,
      text: "Our lead generation increased by 300% within 2 months. The Meta Ads campaigns are incredibly effective."
    },
    {
      name: "Emily Rodriguez",
      company: "Local Restaurant Chain",
      rating: 5,
      text: "Social media management became effortless. Our engagement rates doubled and sales increased by 150%."
    },
    {
      name: "David Thompson",
      company: "Real Estate Agency",
      rating: 5,
      text: "The AI email campaigns generated 50+ qualified leads monthly. ROI exceeded all expectations."
    },
    {
      name: "Lisa Park",
      company: "Beauty Salon",
      rating: 5,
      text: "WhatsApp chatbot handles 80% of our customer inquiries. Staff can focus on actual services now."
    },
    {
      name: "James Wilson",
      company: "Fitness Center",
      rating: 5,
      text: "Workflow automation saved us 20 hours weekly. The efficiency gains are remarkable."
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 4000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const getVisibleTestimonials = () => {
    const visible = [];
    for (let i = 0; i < 3; i++) {
      const index = (currentIndex + i) % testimonials.length;
      visible.push(testimonials[index]);
    }
    return visible;
  };

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            What Our <span className="text-primary">Clients Say</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real results from businesses that trust GenLeads
          </p>
        </div>

        {/* Auto-moving testimonials with left to right scroll */}
        <div className="relative overflow-hidden">
          <div 
            className="flex gap-6 transition-transform duration-1000 ease-in-out"
            style={{
              transform: `translateX(-${currentIndex * (100 / 3)}%)`,
              width: `${(testimonials.length * 100) / 3}%`
            }}
          >
            {testimonials.map((testimonial, index) => (
              <Card 
                key={index}
                className="flex-shrink-0 w-full animate-fade-in"
                style={{ 
                  width: `${100 / testimonials.length}%`,
                  animationDelay: `${index * 0.1}s` 
                }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  
                  <div className="border-t border-border/50 pt-4">
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-primary">{testimonial.company}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Dots indicator */}
        <div className="flex justify-center mt-8 gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentIndex ? 'bg-primary w-6' : 'bg-primary/30'
              }`}
              onClick={() => setCurrentIndex(index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;