import { Button } from "@/components/ui/button";
import { Bot, Calendar } from "lucide-react";

const Navigation = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border/50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <Bot className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-bold text-lg">GenLeads</div>
              <div className="text-xs text-muted-foreground">AI-Powered Growth</div>
            </div>
          </div>
          
          {/* Calendly Link */}
          <Button 
            variant="outline-primary" 
            size="sm"
            onClick={() => window.open('https://calendly.com/genleads', '_blank')}
            className="group"
          >
            <Calendar className="w-4 h-4" />
            Book Consultation
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;